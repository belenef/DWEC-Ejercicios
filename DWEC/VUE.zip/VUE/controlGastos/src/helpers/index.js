export function formatCurrency(value) {

  const number = typeof value === 'number' ? value : Number(value) || 0
  
  return number.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })
}