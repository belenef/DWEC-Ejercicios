export function formatCurrency(value) {

  const number = typeof value === 'number' ? value : Number(value) || 0
  
  return number.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' })
}

export const generarId = () => {
  const fecha = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2);
  return fecha + random;
};

export function formatearFecha(fecha) {
  const opciones = { year: 'numeric', month: 'long', day: '2-digit' };
  return new Date(fecha).toLocaleDateString('es-ES', opciones);
}