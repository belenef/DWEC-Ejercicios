<script setup>
  //en el punto 18 la primera funcion es ValidarGasto en vez de agregarGasto 
  import {ref,reactive,onMounted, computed, watch} from 'vue';
  import Presupuesto from './components/Presupuesto.vue';
  import ControlPresupuesto from './components/ControlPresupuesto.vue';
  import Modal from './components/Modal.vue';

  import iconoNuevoGasto from './assets/img/nuevo-gasto.svg';
  const presupuesto = ref(0);
  const disponible = ref(0);

  // State modal con dos propiedades
  const modal = reactive({
    mostrar: false,
    animar: false
  });

  const gasto = reactive({
    nombre:'',
    cantidad:'',
    categoria:'',
    id:null,
    fecha:15-12-2025
  })

  // Función que se ejecuta cuando el hijo emite el presupuesto
  function definirPresupuesto(valor) {
    presupuesto.value = valor;
    disponible.value = valor;
    console.log('Presupuesto actualizado:', presupuesto.value);
  }

  // Función para mostrar el modal
  function mostrarModal() {
    modal.mostrar = true;
    // esperar a que el modal esté montado antes de activar la animación
    setTimeout(() => {
      modal.animar = true;
    }, 50);
  }

  //  Función para ocultar el modal
  function ocultarModal() {
    // iniciar la animación de salida
    modal.animar = false;
    // al terminar la transición ocultamos el modal
    setTimeout(() => {
      modal.mostrar = false;
    }, 300);
  }
</script>

<template>
  <header>
    <h1>Planificador de Gastos</h1>
  </header>

<main>
  <div class="crear-gasto" v-if="presupuesto > 0" @click="mostrarModal">
    <img :src="iconoNuevoGasto" alt="icono nuevo gasto">
  </div>
  <Modal 
  v-if="modal.mostrar" 
  :modal="modal" 
  :ocultarModal="ocultarModal"
  v-model:nombre="gasto.nombre"
  v-model:cantidad="gasto.cantidad"
  v-model:categoria="gasto.categoria"
  />
</main>

  <div class="contenedor-header contenedor sombra">
      <Presupuesto 
        v-if="presupuesto === 0" 
        @definir-presupuesto="definirPresupuesto" 
      />
      <ControlPresupuesto v-else-if="!modal.mostrar" :presupuesto="presupuesto" :disponible="disponible"/>

  </div>
       
</template>


<style>
:root{
  --azul: #3b82f6;
  --blanco: #fff;
  --gris-claro: #F5F5F5;
  --gris: #94a3b8;
  --gris-oscuro: #64748b;
  --negro: #000;
}


html{
  font-size: 62.5%;
  box-sizing: border-box;
}

*, *:before, *:after{
  box-sizing: inherit;
}

body{
  font-size: 1.6rem;
  font-family: "Lato", sans-serif;
  background-color: var(--gris-claro);
  margin: 0;
  padding: 0;

}
h1{
  font-size: 4rem;
}
h2{
  font-size: 3rem;
}
header{
  background-color: var(--azul);
}
header h1{
  padding: 3rem 0;
  margin: 0;
  color: var(--blanco);
  text-align: center;
}
.contenedor{
  width: 90%;
  max-width: 80rem;
  margin: 0 auto;
}
.contenedor-header{
  margin-top: -5rem;
  transform: translateY(5rem);
  padding: 5rem;
}
.sombra{
  box-shadow: 0px 10px 15px -3px rgba(0,0,0,0.1);
  background-color: var(--blanco);
  border-radius: 1.2rem;
  padding: 5rem;
}

.crear-gasto{
  position:fixed;
  bottom: 5rem;
  right: 5rem;
}
.crear-gasto{
  width: 5rem;
  cursor: pointer;
}
</style>