<script setup> 
  import {ref,reactive,onMounted, computed, watch} from 'vue';
  import Presupuesto from './components/Presupuesto.vue';
  import ControlPresupuesto from './components/ControlPresupuesto.vue';
  import Modal from './components/Modal.vue';
  import Filtro from './components/Filtro.vue';
  import Gasto from './components/Gasto.vue';
  import { generarId } from './helpers';

  import iconoNuevoGasto from './assets/img/nuevo-gasto.svg';
  const presupuesto = ref(0);
  const disponible = ref(0);
  const gastado = ref(0);

  // array de gastos
  const gastos = ref([]);
  const filtro = ref('');
  // indicador para evitar guardar en localStorage durante la inicialización
  const listoParaGuardar = ref(false);

  // State modal con dos propiedades
  const modal = reactive({
    mostrar: false,
    animar: false
  });

  const gasto = reactive({
    nombre:'',
    cantidad:'',
    categoria:'',
    id:null,
    fecha:15-12-2025
  })

  // cantidad original del gasto que se edita
  const cantidadOriginal = ref(null);

  // Guardar un nuevo gasto
  function guardarGasto(gastoRecibido) {
    // si existe gasto.id => estamos editando
    if (gasto.id) {
      const idx = gastos.value.findIndex(g => g.id === gasto.id);
      if (idx !== -1) {
        // conservar id y fecha
        gastos.value[idx] = { ...gastos.value[idx], ...gastoRecibido };
        console.log('Gasto editado:', gastos.value[idx]);
      }
    } else {
      const nuevo = {
        ...gastoRecibido,
        id: generarId(),
        fecha: Date.now()
      };
      gastos.value.push(nuevo);
      console.log('Gasto guardado:', nuevo);
    }
    resetGasto();
    // cerrar modal
    ocultarModal();
  }

  // reutilizable: reinicia los campos del state 'gasto'
  function resetGasto() {
    gasto.nombre = '';
    gasto.cantidad = '';
    gasto.categoria = '';
    gasto.id = null;
    gasto.fecha = null;
    cantidadOriginal.value = null;
  }

  // seleccionar gasto para editar: rellena el state gasto y abre el modal
  function seleccionarGasto(id) {
    const seleccionado = gastos.value.find(g => g.id === id);
    if (!seleccionado) return;
    gasto.nombre = seleccionado.nombre;
    gasto.cantidad = seleccionado.cantidad;
    gasto.categoria = seleccionado.categoria;
    gasto.id = seleccionado.id;
    gasto.fecha = seleccionado.fecha;
    cantidadOriginal.value = seleccionado.cantidad;
    // mostrar modal con datos cargados
    mostrarModal();
  }

  // recalcular gastado y disponible cuando cambian gastos o presupuesto
  watch(gastos, () => {
    const total = gastos.value.reduce((s, g) => s + Number(g.cantidad), 0);
    gastado.value = total;
    disponible.value = Number(presupuesto.value) - total;
    // solo guardamos si ya hemos cargado los datos iniciales
    if (listoParaGuardar.value) guardarLocalStorage();
  }, { deep: true, immediate: true });

  // Computed: lista filtrada según el filtro seleccionado
  const gastosFiltrados = computed(() => {
    if (!filtro.value) return gastos.value;
    return gastos.value.filter(g => g.categoria === filtro.value);
  });

  // cuando cambie el presupuesto, recalculamos disponible
  watch(presupuesto, () => {
    disponible.value = Number(presupuesto.value) - Number(gastado.value);
    // guardar presupuesto en localStorage solo si ya estamos listos
    if (!listoParaGuardar.value) return;
    try {
      localStorage.setItem('presupuesto', String(presupuesto.value));
    } catch (e) {
      console.error('Error guardando presupuesto en localStorage', e);
    }
  });

  // Guardar y cargar gastos en localStorage
  function guardarLocalStorage() {
    try {
      localStorage.setItem('gastos', JSON.stringify(gastos.value));
      // también guardamos el presupuesto para persistir la app completa
      localStorage.setItem('presupuesto', String(presupuesto.value));
    } catch (e) {
      console.error('Error guardando gastos en localStorage', e);
    }
  }

  function cargarLocalStorage() {
    try {
      // cargar presupuesto primero si existe
      const storedPresupuesto = localStorage.getItem('presupuesto');
      if (storedPresupuesto) {
        presupuesto.value = Number(storedPresupuesto);
        disponible.value = Number(presupuesto.value) - Number(gastado.value);
      }

      const stored = localStorage.getItem('gastos');
      if (stored) gastos.value = JSON.parse(stored);
    } catch (e) {
      console.error('Error cargando gastos desde localStorage', e);
    }
  }

  onMounted(() => {
    cargarLocalStorage();
    // indicamos que la app ya cargó y podemos guardar cambios
    listoParaGuardar.value = true;
  });

  // si el modal se cierra (mostrar === false) reiniciamos el state gasto
  watch(() => modal.mostrar, (valor) => {
    if (!valor) resetGasto();
  });

  // Función que se ejecuta cuando el hijo emite el presupuesto
  function definirPresupuesto(valor) {
    presupuesto.value = valor;
    disponible.value = valor;
    console.log('Presupuesto actualizado:', presupuesto.value);
  }

  // Función para mostrar el modal
  function mostrarModal() {
    modal.mostrar = true;
    // esperar a que el modal esté montado antes de activar la animación
    setTimeout(() => {
      modal.animar = true;
    }, 50);
  }

  //  Función para ocultar el modal
  function ocultarModal() {
    // iniciar la animación de salida
    modal.animar = false;
    // al terminar la transición ocultamos el modal
    setTimeout(() => {
      modal.mostrar = false;
    }, 300);
  }

 
  function resetearApp() {
    const confirmar = confirm('¿Seguro que quieres resetear la app? Se eliminará presupuesto y todos los gastos.');
    console.log('Resetear app confirmado?:', confirmar);
    if (!confirmar) return;

    // limpiar estados
    presupuesto.value = 0;
    gastos.value = [];
    gastado.value = 0;
    disponible.value = 0;
    // limpiar almacenamiento local
    try {
      localStorage.removeItem('gastos');
      localStorage.removeItem('presupuesto');
    } catch (e) {
      console.error('Error al limpiar localStorage', e);
    }
  }

  // Eliminar un gasto por id (emitido desde Modal)
  function eliminarGasto(id) {
    gastos.value = gastos.value.filter(g => g.id !== id);
    console.log('Gasto eliminado:', id);
    // cerrar modal y reiniciar el estado del gasto
    ocultarModal();
    resetGasto();
    // la watch sobre gastos actualizará disponible/gastado y guardará en localStorage
  }
</script>

<template>
  <div :class="{ fijar: modal.mostrar }">
    <header>
      <h1>Planificador de Gastos</h1>
    </header>

<main>
  <div class="crear-gasto" v-if="presupuesto > 0" @click="mostrarModal">
    <img :src="iconoNuevoGasto" alt="icono nuevo gasto">
  </div>
  <Modal 
  v-if="modal.mostrar" 
  :modal="modal" 
  :ocultarModal="ocultarModal"
  :disponible="disponible"
  :editar="gasto.id ? true : false"
  :id="gasto.id"
  :cantidad-original="cantidadOriginal"
  v-model:nombre="gasto.nombre"
  v-model:cantidad="gasto.cantidad"
  v-model:categoria="gasto.categoria"
  @guardar-gasto="guardarGasto"
  @eliminar-gasto="eliminarGasto"
  />

</main>



  <div class="contenedor-header contenedor sombra">
      <Presupuesto 
        v-if="presupuesto === 0" 
        @definir-presupuesto="definirPresupuesto" 
      />
      <ControlPresupuesto v-else-if="!modal.mostrar" :presupuesto="presupuesto" :disponible="disponible" :gastado="gastado" @reset-app="resetearApp"/>

  </div>
  <!-- Mostrar filtro sólo cuando hay presupuesto definido -->
  <Filtro v-if="presupuesto > 0" v-model:filtro="filtro" />
  <div v-if="presupuesto > 0" class="listado-gastos contenedor">
    <h2>{{ gastosFiltrados.length === 0 ? 'NO hay gastos' : 'Gastos:' }}</h2>
    <div v-if="gastosFiltrados.length === 0"></div>
      <div v-else class="listado-gastos-grid">
      <Gasto v-for="gastoItem in gastosFiltrados" :key="gastoItem.id" :gasto="gastoItem" @editar-gasto="seleccionarGasto" />
    </div>
  </div>
       
  </div>
</template>


<style>
:root{
  --azul: #3b82f6;
  --blanco: #fff;
  --gris-claro: #F5F5F5;
  --gris: #94a3b8;
  --gris-oscuro: #64748b;
  --negro: #000;
}


html{
  font-size: 62.5%;
  box-sizing: border-box;
}

*, *:before, *:after{
  box-sizing: inherit;
}

body{
  font-size: 1.6rem;
  font-family: "Lato", sans-serif;
  background-color: var(--gris-claro);
  margin: 0;
  padding: 0;
  overflow-x: hidden;

}
h1{
  font-size: 4rem;
}
h2{
  font-size: 3rem;
}
header{
  background-color: var(--azul);
  min-height: 45vh;
  min-width: 95vh;
  position: relative;
  padding-top: 4rem;
  padding-bottom: 4rem;
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
  z-index: 0;
  width: 100%;
}


header h1{
  padding: 3rem 0;
  margin: 0;
  color: var(--blanco);
  text-align: center;
}
.contenedor{
  width: 90%;
  max-width: 80rem;
  margin: 0 auto;
}
.contenedor-header{

  margin-top: calc(-22.5vh + 2.5rem);
  transform: translateY(0);
  padding: 4.5rem;
  position: relative;
  z-index: 10;
}
.sombra{
  box-shadow: 0 18px 30px -10px rgba(0,0,0,0.16);
  background-color: var(--blanco);
  border-radius: 1.2rem;
  padding: 5rem;
}

.crear-gasto{
  position:fixed;
  bottom: 5rem;
  right: 5rem;
}
.crear-gasto{
  width: 5rem;
  cursor: pointer;
}

/* listado de gastos */
.listado-gastos{
  margin-top: 10rem;
}
.listado-gastos h2{
  font-weight: 900;
  color: var(--gris-oscuro);
  text-align: left;
}


.fijar{
  overflow: hidden;
  height: 100vh;
}

.listado-gastos-grid{
  margin-top: 1.6rem;
}
</style>