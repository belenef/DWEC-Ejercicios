<template>
    <!-- muestra la alerta cuando hay error -->
    <Alerta v-if="error">
        {{ error }}
    </Alerta>
    <form class="presupuesto" @submit.prevent="validarPresupuesto">
        <div class="campo">
            <label for="nuevo-presupuesto">Definir Presupuesto</label>

            <input
                id="nuevo-presupuesto"
                class="nuevo-presupuesto"
                placeholder="Indica tu presupuesto"
                type="number"
                v-model.number="presupuestoInicial"
            />

            <input 
                type="submit" 
                value="Aceptar"
            />
        </div>
    </form>
    
</template>

<script setup>
import { ref } from "vue";
import Alerta from "./Alerta.vue";


const presupuestoInicial = ref(0);
const presupuesto = ref(0);

//State para errores
const error = ref("");

const emit = defineEmits(['definir-presupuesto'])

//Función validarPresupuesto
const validarPresupuesto = () => {

    if (presupuestoInicial.value <= 0 || isNaN(presupuestoInicial.value)) {
        error.value = "¡Presupuesto no válido!";

        // Reiniciar después de 3 segundos
        setTimeout(() => {
            error.value = "";
            presupuestoInicial.value = 0;
        }, 3000);

        return;
    }
    emit('definir-presupuesto', presupuestoInicial.value);
    // console.log("Presupuesto válido:", presupuestoInicial.value);
};
</script>

<style>
    :root{
        --azul: #3b82f6;
        --blanco: #fff;
        --gris-claro: #F5F5F5;
        --gris: #94a3b8;
        --gris-oscuro: #64748b;
        --negro: #000;
    }
    .presupuesto{
        width: 100%;
    }
    .campo{
        display: grid;
        gap: 2rem;
    }
    .presupuesto label{
        font-size: 2.2rem;
        text-align: center;
        color: #000;
    }
    .presupuesto input[type="number"]{
        background-color: var(--gris-claro);
        border-radius: 1rem;
        padding: 1rem;
        border: none;
        font-size: 2.2rem;
        text-align: center;
        color: var(--negro);
    }
    .presupuesto input[type="submit"]{
        background-color: var(--azul);
        border: none;
        padding: 1rem;
        font-size: 2rem;
        text-align: center;
        margin-top: 2rem;
        color: var(--blanco);
        font-weight: 900;
        width: 100%;
        transition: background-color 300ms ease;
    }
    .presupuesto input[type="submit"]:hover{
        background-color: #1048A4;
        cursor: pointer;
    }
</style>