<template>
    <div class="dos-columnas">
        <div class="contenedor-grafico">
            <img src="../assets/img/grafico.jpg"/>
        </div>
        <div class="contenedor-presupuesto">
            <button class="reset-app">Resetear app</button>
            <p>
                <span>Presupuesto: </span>{{ formatCurrency(props.presupuesto) }}
            </p>

            <p>
                <span>Disponible:</span>{{ formatCurrency(props.disponible) }}
            </p>

            <p>
                <span>Gastado:</span>0€
            </p>

        </div>

    </div>
</template>

<script setup>
    import imagen from '../assets/img/grafico.jpg'
    import { defineProps } from 'vue'
    //importamos la función para formatear moneda
    import { formatCurrency } from '../helpers/index.js'

// Definimos los props que recibe este componente
const props = defineProps({
  presupuesto: {
    type: Number,
    required: true
  }
    ,
    disponible: {
        type: Number,
        required: true
    }
})
</script>

<style scoped>
    .dos-columnas{
        display: flex;
        flex-direction: column;
    }
    .dos-columnas > :first-child{
        margin-bottom: 3rem;
    }

    @media (min-width: 768px){
        .dos-columnas{
            flex-direction: row;
            gap: 4rem;
            align-items: center;
        }
        .dos-columnas > :first-child{
            margin-bottom: 0;
        }
    }

    .reset-app{
        background-color: #DB2777;
        border: none;
        padding: 1rem;
        width: 100%;
        color: white;
        font-weight: 900;
        text-transform: uppercase;
        border-radius: 1rem;
        transition-property: background-color;
        transition-duration: 300ms;
    }
    .reset-app:hover{
        cursor: pointer;
        background-color: #c11d67;
    }
    .contenedor-presupuesto{
        width: 100%;
    }
    .contenedor-presupuesto p{
        font-size: 2.4rem;
        text-align: center;
        color: darkgray;
    }
    @media (min-width: 768px){
        .contenedor-presupuesto p {
            text-align: left;
        }
    }

    .contenedor-presupuesto span{
        font-weight: 900;
        color: blue;
    }
</style>