<script setup>
import { defineProps } from 'vue'
const emit = defineEmits(['editar-gasto'])
import IconoAhorro from '../assets/img/icono_ahorro.svg'
import IconoCasa from '../assets/img/icono_casa.svg'
import IconoComida from '../assets/img/icono_comida.svg'
import IconoGastos from '../assets/img/icono_gastos.svg'
import IconoOcio from '../assets/img/icono_ocio.svg'
import IconoSalud from '../assets/img/icono_salud.svg'
import IconoSuscripciones from '../assets/img/icono_suscripciones.svg'

import { formatCurrency, formatearFecha } from '../helpers'

const props = defineProps({
  gasto: {
    type: Object,
    required: true
  }
})

const diccionarioIconos = {
  ahorro: IconoAhorro,
  casa: IconoCasa,
  comida: IconoComida,
  gastos: IconoGastos,
  ocio: IconoOcio,
  salud: IconoSalud,
  suscripciones: IconoSuscripciones
}
</script>

<template>
  <div class="gasto">
    <div class="contenido">
      <img :src="diccionarioIconos[gasto.categoria]" :alt="`Icono ${gasto.categoria}`" class="icono" />
      <div class="detalles">
        <p class="categoria">{{ gasto.categoria }}</p>
        <p class="nombre" @click.prevent="$emit('editar-gasto', gasto.id)">{{ gasto.nombre }} <span class="hint">(haz click para editar)</span></p>
        <p class="fecha">Fecha: <span>{{ formatearFecha(gasto.fecha) }}</span></p>
      </div>
    </div>

    <p class="cantidad">{{ formatCurrency(gasto.cantidad) }}</p>
  </div>
</template>

<style scoped>
    :root{
  --azul: #3b82f6;
  --blanco: #fff;
  --gris-claro: #F5F5F5;
  --gris: #94a3b8;
  --gris-oscuro: #64748b;
  --negro: #000;
}
.gasto{
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  background: var(--blanco);
  padding: 1.6rem;
  border-radius: 1rem;
  box-shadow: 0 10px 15px rgba(0,0,0,0.08);
}
.contenido{
  display: flex;
  gap: 2rem;
  align-items: center;
}
.icono{
  width: 5rem;
}
.detalles p{
  margin: 0 0 1rem 0;
}
.detalles{
  text-align: left;
}
.categoria{
  color: var(--gris);
  font-size: 1.2rem;
  text-transform: uppercase;
  font-weight: 900;
}
.nombre{
  color: var(--gris-oscuro);
  font-size: 2.4rem;
  font-weight: 700;
  cursor: pointer;
}
.hint{ font-size: 1.2rem; color: var(--gris); margin-left: 0.6rem; font-weight: 400; }
.fecha{
  color: var(--gris-oscuro);
  font-size: 1.6rem;
  font-weight: 900;
}
.fecha span{
  font-weight: 400;
}
.cantidad{
  font-size: 3rem;
  font-weight: 900;
  margin: 0;
  margin-left: auto;
  text-align: right;
  align-self: center;
  color: #000;
}
</style>
