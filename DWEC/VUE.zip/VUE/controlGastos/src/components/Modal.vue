<script setup>
  import { defineProps } from 'vue'

    const props = defineProps({
        modal: {
            type: Object,
            required: true
        },

        //importamos la función para cerrar el modal a través de props
        ocultarModal: {
                //le decimos que es una función
            type: Function,
            required: true
        },

        // v-model props para el gasto
        nombre: {
            type: String,
            required: true
        },
        cantidad: {
            // puede venir como String (input) o Number
            type: [String, Number],
            required: true
        },
        categoria: {
            type: String,
            required: true
        }
    })

    //declaramos los emits para los v-model
        defineEmits(['update:nombre','update:cantidad','update:categoria']);

    import cerrarModal from '../assets/img/cerrar.svg';
    import Alerta from './Alerta.vue';

    import { ref } from 'vue';

    const error = ref('');

    function validarGasto() {
        if (!props.nombre || props.nombre === '' || props.categoria === '' || props.categoria == null || props.categoria === undefined || props.cantidad === '' || props.cantidad === null || props.cantidad === undefined) {
            error.value = 'TODOS LOS CAMPOS SON OBLIGATORIOS';
            console.log(error.value);
            setTimeout(() => error.value = '', 2000);
            return false;
        }

        if (Number(props.cantidad) <= 0) {
            error.value = 'LA CANTIDAD DEBE SER SUPERIOR A 0';
            console.log(error.value);
            setTimeout(() => error.value = '', 2000);
            return false;
        }

        return true;
    }

    function agregarGasto() {
        const valido = validarGasto();
        if (!valido) return;
        // Para este paso solo comprobamos la lógica
        console.log('Gasto válido:', { nombre: props.nombre, cantidad: props.cantidad, categoria: props.categoria });
    }
</script>

<template>
    <!-- <h1>Desde Modal</h1> -->

    <div class="modal">
        <div class="cerrar-modal" @click="ocultarModal">
            <img :src="cerrarModal" alt="cerrar modal"></img>
        </div>

        <div class="contenedor contenedor-formulario" 
        :class="[ modal.animar ? 'animar' : 'cerrar' ]"
        >
            <form class="nuevo-gasto" @submit.prevent="agregarGasto">
                <legend>Añadir Gasto</legend>
                <!-- renderizamos Alerta para enseñar el error -->
                <Alerta v-if="error">{{ error }}</Alerta>

                <div class="campo">
                    <label for="nombre">Nombre Gasto:</label>
                    <input 
                        id="nombre"
                        type="text"
                        placeholder="Añade el nombre del gasto"
                        :value="nombre"
                        @input="$emit('update:nombre', $event.target.value)"
                    />
                </div>

                <div class="campo">
                    <label for="cantidad">Cantidad Gasto:</label>
                    <input 
                        id="cantidad"
                        type="number"
                        placeholder="Añade la cantidad del gasto"
                        :value="cantidad"
                        @input="$emit('update:cantidad', +$event.target.value)"
                    />
                </div>

                <div class="campo">
                    <label for="categoria">Categoría:</label>
                    <select id="categoria" :value="categoria" @change="$emit('update:categoria', $event.target.value)">
                        <option value="">-- Selecciona --</option>
                        <option value="ahorro">Ahorro</option>
                        <option value="comida">Cesta compra</option>
                        <option value="casa">Casa</option>
                        <option value="ocio">Ocio</option>
                        <option value="salud">Salud</option>
                        <option value="suscripciones">Suscripciones</option>
                        <option value="gastos">Gastos Varios</option>
                    </select>
                </div>

                <input type="submit" value="Añadir Gasto"/>
            </form>
        </div>
    </div>
</template>



<style>

.modal{
    position: fixed;
    background-color: rgb(0 0 0 / 0.9);
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}

.modal{
    z-index: 9999;
}

.cerrar-modal{
    position: absolute;
    right: 3rem;
    top: 3rem;
}
.cerrar-modal img{
    width: 3rem;
    cursor: pointer;
}

.contenedor-formulario{
    transition-property: all;
    transition-duration: 300ms;
    transition-timing-function: ease-in;
    opacity: 0;
}
.contenedor-formulario.animar{
    opacity: 1;
}
.contenedor-formulario.cerrar{
    opacity: 0;
}
.nuevo-gasto{
    display: grid;
    gap: 2rem;
    width: 100%;
    max-width: 60rem;
    padding: 3rem 2.5rem;
    background-color: rgba(0,0,0,0.85);
    border-radius: 1rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}
.nuevo-gasto legend{
   text-align: center;
   color: white;
   font-size: 3rem;
   font-weight: 700;
}
.campo{
    display: grid;
    gap: 2rem;
}
.nuevo-gasto input, .nuevo-gasto select{
    background-color: lightgrey;
    border-radius: 1rem;
    padding: 1rem;
    border: none;
    font-size: 2.2rem;
}
.nuevo-gasto label{
    color: white;
    font-size: 3rem;
}
.nuevo-gasto input[type="submit"]{
    background-color: blue;
    color: white;
    font-weight: 700;
    cursor: pointer;
}
</style>