<script setup>
import { ref, reactive, onMounted, computed } from 'vue';
import { db } from "./data/guitarras";
import Guitarra from "./components/Guitarra.vue";
import Header from "./components/Header.vue";

// const state = reactive({
//   guitarras: [db]
// })

// console.log(state.guitarras);

const carrito = ref([]);
const guitarras = ref([]); 
const guitarra = ref({});
console.log(guitarras.value);

onMounted(() => {
  guitarras.value = db; //ref
  guitarra.value = db[0];
  //state.guitarras = db; //reactive
});

// Buscamos si la guitarra ya está en el carrito
const agregarCarrito = (guitarra) => {
  const itemExistente = carrito.value.find(item => item.id === guitarra.id);

  if (itemExistente) {
    // Si ya existe, solo aumentamos la cantidad
    itemExistente.cantidad++;
  } else {
    // Si no existe, añadimos la guitarra con cantidad 1
    carrito.value.push({ ...guitarra, cantidad: 1 });
  }
};

// Función para incrementar cantidad
const incrementarCantidad = (id) => {
  const item = carrito.value.find(i => i.id === id);
  if (item) item.cantidad++;
};

// Función para decrementar cantidad
const decrementarCantidad = (id) => {
  const item = carrito.value.find(i => i.id === id);
  if (item && item.cantidad > 1) item.cantidad--;
};

// Eliminar producto del carrito
const eliminarProducto = (id) => {
  carrito.value = carrito.value.filter(i => i.id !== id);
};

// Vaciar carrito
const vaciarCarrito = () => {
  carrito.value = [];
};

// Calcular total
const total = computed(() => {
  return carrito.value.reduce((sum, item) => sum + item.precio * item.cantidad, 0);
});
</script>

<template>
  <Header
    :carrito="carrito"
    :total="total"
    @incrementar="incrementarCantidad"
    @decrementar="decrementarCantidad"
    @eliminar="eliminarProducto"
    @vaciar="vaciarCarrito"
  />

  <main class="container-xl mt-5">
    <h2 class="text-center">Nuestra Colección</h2>

    <div class="row mt-5">
      <Guitarra
        v-for="guitarra in guitarras"
        :key="guitarra.id"
        :guitarra="guitarra"
        @agregar-carrito="agregarCarrito"
      />
    </div>
  </main>

  <footer class="bg-dark mt-5 py-5">
    <div class="container-xl">
      <p class="text-white text-center fs-4 mt-4 m-md-0">GuitarLA - Todos los derechos Reservados</p>
    </div>
  </footer>
</template>
