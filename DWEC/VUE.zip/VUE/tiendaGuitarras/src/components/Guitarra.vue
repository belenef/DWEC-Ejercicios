
<template>
            <div class="col-md-6 col-lg-4 my-4 row align-items-center">
                <div class="col-4">
                    <img class="img-fluid"
                    v-bind:src="`./img/${guitarra.imagen}.jpg`"
                    v-bind:alt="'imagen guitarra'  + guitarra.nombre"
                    >
                </div>
                <div class="col-8">
                    <!-- nombre del prop .nombre para llamar al nombre -->
                    <h3 class="text-black fs-4 fw-bold text-uppercase">{{guitarra.nombre}}</h3>
                    <!-- <p>{{ numero }}</p> -->
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit quae labore odit magnam in autem nesciunt, amet deserunt</p>
                    <!-- nombre del prop .precio para llamar al precio -->
                    <p class="fw-black text-primary fs-3">{{guitarra.precio}}€</p>
                    <button 
                        type="button"
                        class="btn btn-dark w-100 "
                        @click="$emit('agregar-carrito', guitarra)"
                    >Agregar al Carrito</button>
                </div>
            </div><!-- FIN GUITARRA -->
</template>

<script setup>
    import {ref} from 'vue'

    //PROP que se llama 'guitarra'
    const props = defineProps({
        guitarra: {
            type: Object,
            required: true
        }
    })

    const numero = ref(0)

    defineEmits(['agregar-carrito'])




</script>

<style lang="scss" scoped>

</style>